yarn install

To test
run - yarn test
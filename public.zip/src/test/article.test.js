import React from 'react';
import { render, waitFor } from '@testing-library/react';
import ArticleList from './ArticleList';
import axios from 'axios';

jest.mock('axios');

const mockData = {
  data: {
    results: [
      { id: 1, title: 'Article 1', abstract: 'Abstract 1', metadata: { url: 'article1.jpg' } },
      { id: 2, title: 'Article 2', abstract: 'Abstract 2', metadata: { url: 'article2.jpg' } },
    ]
  }
};

describe('ArticleList Component', () => {
  beforeEach(() => {
    axios.get.mockResolvedValue(mockData);
  });

  test('renders articles correctly', async () => {
    const { getByText } = render(<ArticleList />);
    await waitFor(() => {
      expect(getByText('Article 1')).toBeInTheDocument();
      expect(getByText('Article 2')).toBeInTheDocument();
    });
  });

  test('fetches articles from API', async () => {
    await render(<ArticleList />);
    expect(axios.get).toHaveBeenCalledWith('https://api.nytimes.com/svc/mostpopular/v2/viewed/1.json?api-key=O7gGsXkWC45redFL7BIsrk5iLrCEqqHw');
  });
});

import {  Col } from "react-bootstrap";
import Button from "react-bootstrap/Button";
import Card from "react-bootstrap/Card";

import "../../App.css";


function Article({article}) {
  
  return (
    <>
      
     
          <Col className="col-lg-4 col-sm-6" key={article?.id}>
            <Card className="my-3">
              {article?.metadata?.url !== null ? 
                <Card.Img variant="top" src={article?.metadata?.url} /> 
                : null}
              <Card.Body>
                <Card.Title>{article?.title}</Card.Title>
                <Card.Text>
                  {article?.abstract}
                </Card.Text>
                <Button variant="primary">Read More</Button>
              </Card.Body>
            </Card>
          </Col>
       
    </>
  );
}

export default Article;